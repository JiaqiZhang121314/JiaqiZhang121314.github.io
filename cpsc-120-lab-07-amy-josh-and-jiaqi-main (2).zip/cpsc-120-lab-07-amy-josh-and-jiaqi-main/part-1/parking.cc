
#include <iostream>
#include <string>
#include <vector>

#include "parking_functions.h"

int main(int argc, char* argv[]) {
  std::vector<std::string> arguments{argv, argv + argc};
  if (argc != 5) {
    std::cout << "error: you must supply four arguments\n";
    return 1;
  }
  std::string street = arguments[1];
  std::string day = arguments[2];
  int hour = std::stoi(arguments[3]);
  int minute = std::stoi(arguments[4]);
  if (street != "ash" && street != "beech" && street != "cedar" &&
      street != "date") {
    std::cerr << "error: invalid street" << std::endl;
    return 1;
  }
  if (day != "mon" && day != "tue" && day != "wed" && day != "thu" &&
      day != "fri" && day != "sat" && day != "sun") {
    std::cerr << "error: invalid day" << std::endl;
    return 1;
  }
  if (hour < 0 || hour > 23) {
    std::cerr << "error: invalid hour" << std::endl;
    return 1;
  }
  if (minute < 0 || minute >= 60) {
    std::cerr << "error: invalid minute" << std::endl;
    return 1;
  }
  bool can_park = false;
  if (day == "wed") {
    can_park = CanParkOnAsh(day, hour);
  } else if (day == "fri") {
    can_park = CanParkOnBeech(day, hour);
  } else if (day == "mon" || day == "tue" || day == "sat" || day == "sun") {
    can_park = CanParkOnCedar(day, hour);
  } else if (day == "sat" || day == "sun") {
    can_park = CanParkOnDate(day, hour, minute);
  }
  if (can_park) {
    std::cout << "allowed\n" << std::endl;
  } else {
    std::cout << "not allowed\n" << std::endl;
  }
  return 0;
}